<html>
    <?php include ('header.php');?>
    <head>
    <link rel="stylesheet" href="detail2.css">
</head>
    <body>
      <section>
<div>
<img src="../image/bi11.png" style=" width:95%;" class="banner">
</div>
<section>
  <div>
    <center>
      <h3 class="head">Bihar</h3>
</center>
  </div>
  <div>
    <h2 class="subtitle">Extra Information</h2><span class="paragrap2"><i class="fa fa-inr" aria-hidden="true" style="padding-right:15px;"><span >Per head:</span><span>4000</span></i><br></span>
    <p class="paragrap">Bihar is a major tourist destination for almost all major religions in India. However, not many people are aware of the various tourist wonders that exist in Bihar.Bodh Gaya, located in the district of Gaya in Bihar, is one of the holiest Buddhist pilgrimages in the world. Under a Bodhi tree in these temple premises, Gautam Buddha was said to have attained enlightenment. In the exact spot where Buddha attained Moksha, the Maha Bodhi temple stands today. 

Apart from the temple, a direct descendent of the actual tree under which Buddha attained enlightenment is also present in the temple premises today. There is also a sacred lotus pond along with six other sacred sites of great eminence and reverence to Buddhism. Bodh Gaya is the top must-visit tourist place of Bihar.Nalanda Mahavihara was the first residential university in the world. It was a Buddhist monastic university that was one of the most important learning centres in the world at its time. Built and operated during the Gupta empire of India, this university helped propel the patronage of arts and academics in India at that time.
The Valmiki National Park is one of the most underrated tiger reserves in the country. It is estimated that there are 40 tigers living in this national park, and it is one of the best places for you to see tigers in the wild. This national park is located at the border of India and Nepal in the West Champaran district of Bihar</p>
</div>
</section>
      
</section>
      <section style="margin-left:25px;margin-right:25px;">
<div class="container-fluid">
  <div class="row">
    <div class="col-sm-4" >
    <div class="container">
    <img src="../image/bi1.png" style="width:90%" class="img-card image pack1" >
            <div class="middle">
              <div class="text">Museum</div>
            </div>
          </div></div>
    <div class="col-sm-4"><div class="container">
        <img src="../image/bi2.png" style="width:90%"  class="img-card image pack1" >
            <div class="middle">
              <div class="text">Old Temple</div>
            </div>
          </div></div>
    <div class="col-sm-4" ><div class="container">
        <img src="../image/bi3.png" style="width:90%"  class="img-card image pack1" >
            <div class="middle">
              <div class="text">Old palace</div>
            </div>
          </div></div>
  </div>
</div>
<center class="button_dbms">
  <h5><b>Before You Book Your Tour Please Read<a href="condition.php"> Terms and Conditions</a><span style="color:#ff3f00;">**</span></b></h5>
</center>
<center class="button_dbms">
<div class="button-1">
                           <button class="button" onclick="button()"><span>Book</span></button>
                        </div>
</center>

                        <?php include ('footer.php');?>
</section>
    </body>
    <script>
      function button(){
  location.replace("regsiter.php")
}
      </script>
                  <style>
        .button_dbms{margin-bottom:10px;margin-top:20px;}
        .button_dbm{margin-top:30px; margin-left:70vh;}
         @media only screen and (max-width: 600px) {
          .paragrap2 {
    float: right;
    margin-top: 0px;
    margin-right: 125px;
    font-size: 25px;
    color: #ff3f00;
    font-family: cursive;
    font-weight: bold;
}
.paragrap{
  padding-top:55px;
}
.button-1 {
    text-align: left;
    margin-left: 7vh;
}
.head {
    font-family: cursive;
    color: #ff3f00;
    font-size: 35px;
    font-weight: bolder;
    margin-top: 20px;
}
.pack1 {
    margin-left: 17px;
    height: auto;
    padding-top: 15px;
    padding-bottom: 15px;
}
.banner {
    width: 90% !important;
    max-height: 50vh;
    margin-left: 16px;
    border-radius: 20px;
    height: 95px;
}
.button_dbm{margin-top:30px; margin-left:0vh;}
         }
         </style>
</html>
