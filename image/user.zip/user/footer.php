        <section style="margin-top: 55px;">
          <div style="background-color: black; color: white;">
          <div class="container-fluid">
      <div class="row">
        <div class="col-sm-4 foot" style="padding-left: 7%; padding-top:65px ;">
          <h5 class="head_1"><b>Contact Us</b></h5>
          <i class="fa fa-envelope-o right-1" aria-hidden="true" style="font-size: 25px; margin-top: 5vh;"></i>
          <h6 class="col_31">toruism-234@gmail.com<br>
            sema5543@gmail.com</h6>
           <span> <i class="fa fa-map-marker right-2" aria-hidden="true" style="font-size: 28px; padding-top: 29px;"></i></span>
            <h6 class="col_3"> Athreya HouseNo.1,<br>
              Thiruvalluvar nagar,<br>
              Salem district,<br>
              Mettur dam - 636456,<br>
              Tamil Nadu, India</h6>
              <div style="margin-top: 40px;">
                <i class="fa fa-phone right-3" aria-hidden="true" style="font-size: 28px;"></i>  
              <h6 class="col_3">+91-7653455635<br>
                +91-6404875230</h6>
              </div>
              
        </div>
      
        <div class="col-sm-4 foot  quick" >
          <h5 class="head_1"><b>Quick Links</b></h5>
          <div class="footer-1">
            <h6 class="h6"><a href="home.php" style="color:white;">Home</a></h6>
          <h6 class="h6"><a href="about.php"style="color:white;">About Us</a></h6>
          <h6 class="h6"><a href="package_list.php"style="color:white;">Tour Package</a></h6>
          <h6 class="h6"><a href="condition.php" style="color:white;">Term & Condition</a></h6>
          <h6 class="h6"><a href="contact.php" style="color:white;">Our Team</a></h6>
          <h6 class="h6"><a href="recover.php" style="color:white;">Enquiry</a></h6>

          </div>
                  </div>
        
        <div class="col-sm-4 foot footer_dbms">
          <h5 class="head_1">Available at</h5>
          <div id="footer-icon2">
            <a href=""><i class="fa fa-facebook footer-icon " id="footer-icon1"  aria-hidden="true"></i></a>
            <a href=""><i class="fa fa-twitter footer-icon" aria-hidden="true"></i></a>
           <a href=""><i class="fa fa-instagram footer-icon" aria-hidden="true"></i></a>
            <a href=""><i class="fa fa-linkedin footer-icon" aria-hidden="true"></i></a>
          </div>
        </div>
        </div>
      </div>
          </div>
        </section>
        <style>
          .quick{
          padding-top:65px ;padding-left: 20vh;
          }
          .footer_dbms{
            padding-top: 65px;
          }
   @media only screen and (max-width: 600px) {
	.quick {
    padding-top:65px ;padding-left: 5vh;
	}
 .footer_dbms {
    padding-top: 65px;
    padding-bottom: 45px;
}
 }
  </style>