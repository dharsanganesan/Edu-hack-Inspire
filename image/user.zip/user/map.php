<head>
    <title>DBMS</title>
    <link rel="shortcut icon" type="image/png" href="../image/logo1.jpg">
    <meta charset="UTF-8">
    <link rel="stylesheet" href="home.css">
    <script src="script.js" defer></script>
    <link rel="stylesheet" href="bot.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet"
    href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
  <link rel="stylesheet"
    href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@48,400,1,0" />
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<section>
        <div class="body hide_dbms view_home">
            <div>
                <img src="../image/tour.png" width="100px" height="100px">
            </div>
            <ul>
    <li><a href="home.php">Home</a></li>
    <li><a href="map.php">Map</a></li>
    <li><a href="about.php">About</a></li>
    <li><a href="package_list.php">Tour Package</a></li>
    <li><a href="condition.php">Terms & Condition</a></li>
    <li><a href="contact.php">Our Team</a></li>
    <li><a href="recover.php">Enquiry</a></li>
  </ul>
  <div class="icon">

    <a href="#" style="color:black;"><i class="fa fa-user" aria-hidden="true"></i></a>
    <a href="log.php" style="color:black;"><i class="fa fa-sign-out icon-home" aria-hidden="true"></i></a>
  </div>
 
        </div>
    </section>
    <section>
    <div class="view_dbms hide_home">
    <div>
                <img src="../image/tour.png" width="100px" height="100px">
            </div>
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="home.php">Home</a>
  <a href="map.php">Map</a>
  <a href="about.php">About</a>
  <a href="package_list.php">Tour Package</a>
  <a href="condition.php">Terms & Condition</a>
  <a href="contact.php">Our Team</a>
  <a href="recover.php">Enquiry</a>
</div>
<span class="colse" onclick="openNav()">&#9776;</span>
</div>
</section>
<style>

    body {
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
}

#chartdiv {
  width: 100%;
  height:100%;
  margin-top:15vh;
}

</style>
<body >
    <script src="https://www.amcharts.com/lib/4/core.js"></script>
    <script src="https://www.amcharts.com/lib/4/maps.js"></script>
    <script src="https://www.amcharts.com/lib/4/geodata/india2019High.js"></script>
    <script src="https://www.amcharts.com/lib/4/themes/animated.js"></script>
    <div><h1 style="text-align:center;font-family:cursive;color:red;">India Map</h1></div>
    <div id="chartdiv"></div> 
</body>
<script>
    // Themes begin
am4core.useTheme(am4themes_animated);
// Themes end

// Create map instance
var chart = am4core.create("chartdiv", am4maps.MapChart);

// Set map definition
chart.geodata = am4geodata_india2019High;

// Create map polygon series
var polygonSeries = chart.series.push(new am4maps.MapPolygonSeries());

//Set min/max fill color for each area
polygonSeries.heatRules.push({
  property: "fill",
  target: polygonSeries.mapPolygons.template,
  min: chart.colors.getIndex(0).brighten(1),  
  min: chart.colors.getIndex(1).brighten(0.3),
  // logarithmic: true
 // "min": am4core.color("#ffd7b1"), 
});

// Make map load polygon data (state shapes and names) from GeoJSON
polygonSeries.useGeodata = true;

// Set heatmap values for each state
polygonSeries.data = [
  {
    id: "IN-JK",
    value: 7
  },
  {
    id: "IN-MH",
    value:7

  },
  {
    id: "IN-UP",
    value: 10
  },
  {
    id: "US-AR",
    value: 5
  },
  {
    id: "IN-RJ",
    value:6
  },
  {
    id: "IN-AP",
    value:5
  },
  {
    id: "IN-MP",
    value:0
  },
  {
    id: "IN-TN",
    value: 12
  },
  {
    id: "IN-JH",
    value:4
  },
  {
    id: "IN-WB",
    value: 7
  },
  {
    id: "IN-GJ",
    value:1
  },
  {
    id: "IN-BR",
    value:4
  },
  {
    id: "IN-TG",
    value: 5
  },
  {
    id: "IN-GA",
    value: 6
  },
  {
    id: "IN-DN",
    value: 0
  },
  {
    id: "IN-DL",
    value: 0
  },
  {
    id: "IN-DD",
    value: 4
  },
  {
    id: "IN-CH",
    value: 7
  },
  {
    id: "IN-CT",
    value: 0
  },
  {
    id: "IN-AS",
    value: 6
  },
  {
    id: "IN-AR",
    value: 5
  },
  {
    id: "IN-AN",
    value: 1
  },
  {
    id: "IN-KA",
    value: 6
  },
  {
    id: "IN-KL",
    value: 8
  },
  {
    id: "IN-OR",
    value: 8
  },
  {
    id: "IN-SK",
    value: 5
  },
  {
    id: "IN-HP",
    value:5
  },
  {
    id: "IN-PB",
    value: 4
  },
  {
    id: "IN-HR",
    value: 1
  },
  {
    id: "IN-UT",
    value: 1
  },
  {
    id: "IN-LK",
    value: 12
  },
  {
    id: "IN-MN",
    value: 5
  },
  {
    id: "IN-TR",
    value: 0
  },
  {
    id: "IN-MZ",
    value: 0
  },
  {
    id: "IN-NL",
    value: 0
  },
  {
    id: "IN-ML",
    value: 3
  }
];

// Configure series tooltip
var polygonTemplate = polygonSeries.mapPolygons.template;
polygonTemplate.tooltipText = "{name}: {value}";
polygonTemplate.nonScalingStroke = true;
polygonTemplate.strokeWidth = 0.5;

// Create hover state and set alternative fill color
var hs = polygonTemplate.states.create("hover");
hs.properties.fill = am4core.color("#ff7d01");

</script>
<style>
  .hide_home{
	visibility: hidden;
	display: none;
}
ul {
    padding: 0;
    margin: 0;
    display: flex;
    flex-wrap: wrap;
    margin-left: 30px;
}
.body {
    align-items: center;
    font-family: times;
    background-color: white;
    display: flex;
    margin-left: 30px;
}
.view_home{
	visibility: visible;
}
  /* for footer end */
  @media only screen and (max-width: 600px) {
	.hide_dbms{
		visibility: hidden;
		display: none;
	}
	.view_dbms{
		visibility: visible;
        display: block;
	}
  .sidenav {
	height: 100%;
	width: 0;
	position: fixed;
	z-index: 5;
	top: 0;
  right: 0;
	background-color: black !important;
	overflow-x: hidden;
	transition: 0.5s;
	padding-top: 60px;
  }
  
  .sidenav a {
	padding: 8px 8px 8px 32px;
	text-decoration: none;
	font-size: 25px;
	color: #ff3f00;
  font-family:cursive !important;
	display: block;
	transition: 0.3s;
  }
  
  .sidenav a:hover {
	color: #f1f1f1;
  }
  
  .sidenav .closebtn {
	position: absolute;
	top: 0;
	right: 25px;
	font-size: 36px;
	margin-left: 50px;
  }
  .colse{
  font-size: 30px;
    cursor: pointer;
     margin-top:-10vh; 
        float: right;
   margin-right: 20px; 
    margin-bottom: 18px; 
}
/*   

  @media screen and (max-height: 450px) {
	.sidenav {padding-top: 15px;}
	.sidenav a {font-size: 18px;}
  } */
}

  </style>
      <script>
function openNav() {
  document.getElementById("mySidenav").style.width = "100%";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>
<section style="margin-top: 55px;">
          <div style="background-color: black; color: white;">
          <div class="container-fluid">
      <div class="row">
        <div class="col-sm-4 foot" style="padding-left: 7%; padding-top:65px ;">
          <h5 class="head_1"><b>Contact Us</b></h5>
          <i class="fa fa-envelope-o right-1" aria-hidden="true" style="font-size: 25px; margin-top: 5vh;"></i>
          <h6 class="col_31">toruism-234@gmail.com<br>
            sema5543@gmail.com</h6>
           <span> <i class="fa fa-map-marker right-2" aria-hidden="true" style="font-size: 28px; padding-top: 29px;"></i></span>
            <h6 class="col_3"> Athreya HouseNo.1,<br>
              Thiruvalluvar nagar,<br>
              Salem district,<br>
              Mettur dam - 636456,<br>
              Tamil Nadu, India</h6>
              <div style="margin-top: 40px;">
                <i class="fa fa-phone right-3" aria-hidden="true" style="font-size: 28px;"></i>  
              <h6 class="col_3">+91-7653455635<br>
                +91-6404875230</h6>
              </div>
              
        </div>
      
        <div class="col-sm-4 foot  quick" >
          <h5 class="head_1"><b>Quick Links</b></h5>
          <div class="footer-1">
            <h6 class="h6"><a href="home.php" style="color:white;">Home</a></h6>
          <h6 class="h6"><a href="about.php"style="color:white;">About Us</a></h6>
          <h6 class="h6"><a href="package_list.php"style="color:white;">Tour Package</a></h6>
          <h6 class="h6"><a href="condition.php" style="color:white;">Term & Condition</a></h6>
          <h6 class="h6"><a href="contact.php" style="color:white;">Our Team</a></h6>
          <h6 class="h6"><a href="recover.php" style="color:white;">Enquiry</a></h6>

          </div>
                  </div>
        
        <div class="col-sm-4 foot footer_dbms">
          <h5 class="head_1">Available at</h5>
          <div id="footer-icon2">
            <a href=""><i class="fa fa-facebook footer-icon " id="footer-icon1"  aria-hidden="true"></i></a>
            <a href=""><i class="fa fa-twitter footer-icon" aria-hidden="true"></i></a>
           <a href=""><i class="fa fa-instagram footer-icon" aria-hidden="true"></i></a>
            <a href=""><i class="fa fa-linkedin footer-icon" aria-hidden="true"></i></a>
          </div>
        </div>
        </div>
      </div>
          </div>
        </section>
        <style>
          .quick{
          padding-top:65px ;padding-left: 20vh;
          }
          .footer_dbms{
            padding-top: 65px;
          }
   @media only screen and (max-width: 600px) {
	.quick {
    padding-top:65px ;padding-left: 5vh;
	}
 .footer_dbms {
    padding-top: 65px;
    padding-bottom: 45px;
}
 }
  </style>