
<?php include ('header.php');?>
<section>
    <div>
        <img src="../image/aboutus.jpg" alt="About" width="100%" height="40%">
    </div>
    <div style="margin-left:20px; margin-top:25px;">
        <h2 class="header"><b> About Us</b></h2>
        <h3 class="head-para">Welcome to india tourist website!!!</h3>
        <p class="head-parag">Since then, our courteous and committed team members have always ensured a pleasant and enjoyable tour for the clients. This arduous effort has enabled TMS to be recognized as a dependable Travel Solutions provider with three offices Delhi. We have got packages to suit the discerning traveler's budget and savor. Book your dream vacation online. Supported quality and proposals of our travel consultants, we have a tendency to welcome you to decide on from holidays packages and customize them according to your plan.</p>
</div>
</section>

<?php include ('footer.php');?>
    </body>
    <style>
        .header{
    text-decoration: underline;
    color: #ff3f00;
    font-family: cursive;
    margin-top: 15px;
    margin-left: 10px;
    text-align: center;
}
.head-para{
    color: #ff3f00;
    font-family: cursive;
    margin-top: 15px;
    margin-left: 70px;
    text-align: center;
}
.head-parag{
    margin-left: 10px;
    margin-right: 16px;
    color: black;
    font-size: 26px;
    text-align: center;
    font-family: cursive;
    margin-top: 35px;
}
@media only screen and (max-width: 600px) {
    .head-para {
    color: #ff3f00;
    font-family: cursive;
    margin-top: 15px;
    margin-left:0px;
    text-align: center;
}
}
        </style>
</html>