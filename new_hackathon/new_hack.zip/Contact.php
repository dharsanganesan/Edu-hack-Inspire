<?php include 'navbar.php'; ?>
  <head>
  <link rel="stylesheet" href="common.css">
</head>
    <div class="container top_topic" style="margin-top: 10vh !important;margin-bottom: 0vh !important;">
      <h1>Event Co-ordinators</h1>
      <table>
        <tr>
          <th>Name</th>
          <th>Email Id</th>
          <th>Phone No</th>
        </tr>
        <tr><td colspan="3">Teacher</td></tr>
        <tr>
          <td>John Doe</td>
          <td>johndoe@example.com</td>
          <td>1234567890</td>
        </tr>
        <tr>
          <td>Jane Doe</td>
          <td>janedoe@example.com</td>
          <td>9876543210</td>
        </tr>
        <tr><td colspan="3">Student</td></tr>
        <tr>
          <td>Jaisurya</td>
          <td>Jaisurya2309@gmail.com</td>
          <td>6382066445</td>
        </tr>
        <tr>
          <td>Sabari</td>
          <td>sabari345@gmail.com</td>
          <td>9342952824</td>
        </tr>
        <tr>
          <td>Sanjay Kumar</td>
          <td>sanjaykumar345@gmail.com</td>
          <td>9342952824</td>
        </tr>
      </table>
      </div>
    </div>
    <div class="container" style="margin-top:5%;">
      <h1>Location</h1>
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d686.0588115714165!2d77.99967325920299!3d11.476501121072095!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3babe0bee4ef722b%3A0xa949856b58bb6c9e!2sMahendra%20Engineering%20College!5e1!3m2!1sen!2sin!4v1729525626080!5m2!1sen!2sin"class="map_hacker" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
    <div class="cursor" style="z-index: 100;"></div>
    <div class="cursor2" style="z-index: 100;"></div>
    <div class="particles"></div>
    <div class="star-background"></div>
  </body>
  <script src="hack_script.js"></script>
</html>
