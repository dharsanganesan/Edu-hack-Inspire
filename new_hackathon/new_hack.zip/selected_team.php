<?php include 'navbar.php'; ?>
  <head>
  <link rel="stylesheet" href="common.css">
</head>
    <div class="container top_topic">
      <h1>Selected Teams</h1>
      <table  style="width: 85%; margin-top: 30px;">
        <tr>
          <th>S.no</th>
          <th>Domain Name</th>
          <th>Team Leader Name</th>
          <th>College Name</th>
          <th>Mail ID</th>
        </tr>
<tr>
    <td>---</td>
    <td>---</td>
    <td>---</td>
    <td>---</td>
    <td>---</td>
</tr>
      </table>
      <div style="margin-top: 35px;">
        <h3>It will be Post on 8/11/2024</h3>
      </div>
      </div>
    </div>
    <div class="cursor"style="z-index: 100;"></div>
    <div class="cursor2" style="z-index: 100;"></div>
    <div class="particles"></div>
    <div class="star-background"></div>
  </body>
  <script src="hack_script.js"></script>
</html>
