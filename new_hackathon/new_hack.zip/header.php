  <head>
    <meta charset="UTF-8">
    <meta charset="utf-8">   
    <title>EduInspire Hackathon</title>
    <link rel="shortcut icon" type="image/png" href="hack_logo.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="hack_style.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap" rel="stylesheet">  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
  </head>
  <div class="navbar view hide_mobile" id="navbar">
      <div class="logo">
      <img src="hack_logo.png" class="hack_img" style="width: 80px;">
      </div>
      <div class="nav-links">
        <a href="index.php">Home</a>
        <a href="about_hack.php">About</a>
        <a href="selected_team.php">Shortlisted Teams  <span style="color: #ff4081;"><i class="fa fa-certificate" aria-hidden="true"></i></span></a>
        <a href="Contact.php">Contact</a>
        <a href="FAQ_hack.php">FAQ</a>
      </div>
    </div>

<section class="hide view_mobile">
  
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="index.php">Home</a>
        <a href="about_hack.php">About</a>
        <a href="selected_team.php">Shortlisted Teams  <span style="color: #ff4081;"><i class="fa fa-certificate" aria-hidden="true"></i></span></a>
        <a href="Contact.php">Contact</a>
        <a href="FAQ_hack.php">FAQ</a>
</div>
<img src="hack_logo.png" class="hack_img" style="width: 40px;">
<span class="open" onclick="openNav()">&#9776;</span>
</section>
